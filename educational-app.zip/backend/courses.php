<?php
// Fetch and display courses logic here
?>